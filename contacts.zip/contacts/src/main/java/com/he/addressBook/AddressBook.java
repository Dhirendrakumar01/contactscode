package com.he.addressBook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddressBook {
	private List<Contact> contacts = new ArrayList<Contact>();

    public AddressBook() {
        //TODO
    }

    public void addContact(Contact contact) {
        //TODO
    	
    	this.contacts.add(contact);
   
         
    }

    public void deleteContact(String name) {
        //TODO
    	
    	this.contacts.remove(name);
        
    }

    public void updateContact(String name, Contact contact) {
    	
         
    	for(int i = 0; i < contact.size(); i++){
    		Contact p = (Contact)contact.get(i); 
              if(name.equals(p.name)){
            	  contact.remove(i); }
               }
        
        //TODO
    }

    public List<Contact> searchByName(String name) {
        //TODO
    	for(int i = 0; i < persons.size(); i++){
            PersonInfo p = (PersonInfo)persons.get(i); 
            if(name.equals(p.name)){
             p.print();
               
          }//if statment
   }
      
        
    }

    public List<Contact> searchByOrganisation(String organisation) {
        //TODO
    	for(int i = 0; i < organisation; i++){
    		Contact p = (Contact)persons.get(i); 
            if(name.equals(p.name)){
             p.print();
               
          }//if statment
   }
      
        return p;
    }

}